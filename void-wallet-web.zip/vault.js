// Secrets: the recovery phrase is encrypted with a key derived from the PIN (PBKDF2 + AES-GCM, via the
// browser's built-in WebCrypto) and kept in this browser's local storage. A wrong PIN fails decryption.
// This is weaker than the Android app, which keeps its secrets in the phone's hardware-backed keystore.
export const MAX_FAILS = 5;
const ITER = 150000;
const enc = new TextEncoder();
const dec = new TextDecoder();

const K = {
  vault: { main: 'vw_vault_main', decoy: 'vw_vault_decoy' },
  sendpw: { main: 'vw_sendpw_main', decoy: 'vw_sendpw_decoy' },
  fails: 'vw_fails',
};

const get = (k) => {
  try {
    return localStorage.getItem(k);
  } catch {
    return null;
  }
};
const set = (k, v) => localStorage.setItem(k, v);
const del = (k) => {
  try {
    localStorage.removeItem(k);
  } catch {}
};

const b64 = (u8) => btoa(String.fromCharCode(...u8));
const unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
const rand = (n) => crypto.getRandomValues(new Uint8Array(n));

async function baseKey(secret) {
  return crypto.subtle.importKey('raw', enc.encode(secret), 'PBKDF2', false, ['deriveKey', 'deriveBits']);
}
async function aesKey(secret, salt) {
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', hash: 'SHA-256', salt, iterations: ITER },
    await baseKey(secret),
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

async function encrypt(secret, text) {
  const salt = rand(16);
  const iv = rand(12);
  const key = await aesKey(secret, salt);
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, enc.encode(text)));
  return JSON.stringify({ v: 1, s: b64(salt), i: b64(iv), c: b64(ct) });
}

async function decrypt(secret, blob) {
  try {
    const o = JSON.parse(blob);
    const key = await aesKey(secret, unb64(o.s));
    const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(o.i) }, key, unb64(o.c));
    return dec.decode(pt);
  } catch {
    return null;
  }
}

async function dummy(secret) {
  await aesKey(secret, new Uint8Array(16)); // same work as a real attempt, so timing does not reveal a decoy
  return null;
}

// ---------- wallets ----------
export async function hasWallet() {
  return get(K.vault.main) != null;
}
export async function hasDecoy() {
  return get(K.vault.decoy) != null;
}
export async function saveVault(ns, pin, mnemonic) {
  set(K.vault[ns], await encrypt(pin, mnemonic));
}
export async function removeDecoy() {
  del(K.vault.decoy);
  del(K.sendpw.decoy);
  del('vw_state_decoy');
  del('vw_cache_decoy');
}

// Returns {ns, mnemonic} for the wallet this PIN opens, or null.
export async function tryUnlock(pin) {
  const mainBlob = get(K.vault.main);
  const decoyBlob = get(K.vault.decoy);
  const [m, d] = await Promise.all([
    mainBlob ? decrypt(pin, mainBlob) : dummy(pin),
    decoyBlob ? decrypt(pin, decoyBlob) : dummy(pin),
  ]);
  if (m !== null) return { ns: 'main', mnemonic: m };
  if (d !== null) return { ns: 'decoy', mnemonic: d };
  return null;
}
export async function pinMatchesMain(pin) {
  const blob = get(K.vault.main);
  return blob ? (await decrypt(pin, blob)) !== null : false;
}
export async function changePin(ns, oldPin, newPin) {
  const blob = get(K.vault[ns]);
  if (!blob) return false;
  const mnemonic = await decrypt(oldPin, blob);
  if (mnemonic === null) return false;
  await saveVault(ns, newPin, mnemonic);
  return true;
}

// ---------- failed PIN counter ----------
export async function getFails() {
  return parseInt(get(K.fails) || '0', 10) || 0;
}
export async function setFails(n) {
  set(K.fails, String(n));
}

// ---------- send password ----------
async function hashPw(password, salt) {
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', hash: 'SHA-256', salt, iterations: ITER },
    await baseKey(password),
    256
  );
  return new Uint8Array(bits);
}
export async function setSendPassword(ns, password) {
  const salt = rand(16);
  set(K.sendpw[ns], JSON.stringify({ s: b64(salt), h: b64(await hashPw(password, salt)) }));
}
export async function checkSendPassword(ns, password) {
  const stored = get(K.sendpw[ns]);
  if (!stored) return false;
  const o = JSON.parse(stored);
  const a = await hashPw(password, unb64(o.s));
  const b = unb64(o.h);
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
  return diff === 0;
}

// ---------- erase everything ----------
export async function wipeAll() {
  try {
    localStorage.clear();
    sessionStorage.clear();
  } catch {}
}
