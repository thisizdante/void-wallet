import { COINS, LIVE_COINS, DEFAULT_NODES, formatUnits, parseUnits, toUsd, fmtUsd, explorerUrl } from './chains/config.js';
import * as L from './lazy.js';
import * as V from './vault.js';

// Real networks stay off in the web version. Use the Android app for real funds.
const ALLOW_MAIN = false;

const root = document.getElementById('app');
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const msg = (e) => String((e && e.message) || e);
const $ = (id) => document.getElementById(id);
const val = (id) => ($(id) ? $(id).value : '');

const DEF = () => ({
  net: 'test',
  nodes: {},
  fresh: { BTC: true, ETH: true, TRX: true, SOL: true, XRP: false, XLM: false },
  index: {},
  hide: false,
  history: [],
  backedUp: false,
  needsScan: false,
});

const S = {
  screen: 'loading', ns: 'main', mnemonic: '', seed: null, cfg: DEF(),
  addrs: {}, bals: {}, prices: {}, priceStale: false, errors: {}, refreshing: false,
  banner: null, tab: 'wallet', ov: null, sub: null, picking: null, note: null, libErr: null,
};
let OB = {};
let SD = {};
let R = {};
let pinBuf = '';
let padCb = null;
let padBusy = false;
let timer = null;
let hiddenAt = 0;
const addrCache = new Map();
const lastTotals = {};

// ---------------------------------------------------------------- storage / config helpers
const saveCfg = () => {
  try { localStorage.setItem('vw_state_' + S.ns, JSON.stringify(S.cfg)); } catch {}
};
const patch = (p) => { Object.assign(S.cfg, p); saveCfg(); };
const key = (coin) => `${S.cfg.net}:${coin}`;
const nodeFor = (coin) => (S.cfg.nodes[key(coin)] || '').trim() || DEFAULT_NODES[S.cfg.net][coin];
const curIdx = (coin) => S.cfg.index[key(coin)] ?? 0;
const totalOf = (coin) => (S.bals[coin] || []).reduce((a, b) => a + b, 0n);

// ---------------------------------------------------------------- icons
const ico = {
  wallet: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7a2 2 0 0 1 2-2h13v4"/><path d="M3 7v11a2 2 0 0 0 2 2h14a1 1 0 0 0 1-1v-9a1 1 0 0 0-1-1H5a2 2 0 0 1-2-2z"/><circle cx="16.5" cy="14.5" r="1" fill="currentColor"/></svg>',
  swap: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M7 4 3 8l4 4M3 8h14M17 20l4-4-4-4M21 16H7"/></svg>',
  gear: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3h0a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5h0a1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8v0a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>',
  eye: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#9A9AB8" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg>',
  eyeOff: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#9A9AB8" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M17.9 17.9A10.9 10.9 0 0 1 12 19C5 19 1 12 1 12a18 18 0 0 1 5.1-5.9M9.9 5.1A10.4 10.4 0 0 1 12 5c7 0 11 7 11 7a18 18 0 0 1-2.2 3.2M1 1l22 22"/></svg>',
  lock: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#9A9AB8" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>',
  refresh: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#9A9AB8" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-3-6.7L21 8M21 3v5h-5"/></svg>',
};

// ---------------------------------------------------------------- small view helpers
const notice = (text, tone = '') => `<div class="notice ${tone}">${esc(text)}</div>`;
const btn = (act, text, cls = 'primary', extra = '') => `<button class="btn ${cls}" data-act="${act}" ${extra}>${text}</button>`;
const avatar = (coin, big) => {
  const c = COINS[coin].color;
  return `<div class="avatar${big ? ' big' : ''}" style="color:${c};border-color:${c};background:${c}33">${coin}</div>`;
};
const bar = (title, back) =>
  `<div class="row between mb14"><button class="ibtn back" data-act="${back}">← Back</button><span class="small">${esc(title || '')}</span></div>`;
const switchEl = (act, on, extra = '') =>
  `<label class="sw"><input type="checkbox" data-act="${act}" ${extra} ${on ? 'checked' : ''}><span></span></label>`;
const spinner = '<span class="spin"></span>';

function padHTML() {
  const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', '⌫'];
  return `<div class="dots">${'<span class="dot"></span>'.repeat(6)}</div>
  <div class="keys">${keys.map((k) => (k === '' ? '<span></span>' : `<button class="key" data-act="pin" data-d="${k}" aria-label="${k === '⌫' ? 'Delete' : k}">${k}</button>`)).join('')}</div>`;
}
function pinScreen(title, sub, cb, err, extra = '') {
  padCb = cb;
  return `<div class="pad center" style="padding-top:44px"><h1>${esc(title)}</h1><p class="sub">${esc(sub || '')}</p>
  ${err ? `<p class="warn" style="margin:10px 0 0">${esc(err)}</p>` : ''}${padHTML()}${extra}</div>`;
}
function updateDots() {
  root.querySelectorAll('.dot').forEach((d, i) => d.classList.toggle('f', i < pinBuf.length));
}

// ---------------------------------------------------------------- render
function render() {
  pinBuf = '';
  padCb = null;
  let html = '';
  try {
    html = view();
  } catch (e) {
    html = `<div class="pad"><h1>Something went wrong</h1><div class="notice bad">${esc(msg(e))}</div>${btn('lock', 'Lock')}</div>`;
  }
  root.innerHTML = html;
}
function go(screen) {
  S.screen = screen;
  render();
  window.scrollTo(0, 0);
}
// Re-render only screens that have no text being typed
function softRender() {
  if (S.screen !== 'app') return;
  if (S.ov ? S.ov.kind === 'coin' : S.tab === 'wallet' && !S.sub) render();
}

function view() {
  switch (S.screen) {
    case 'loading': return `<div class="pad center"><div class="spin" style="margin:40vh auto 0"></div></div>`;
    case 'welcome': return vWelcome();
    case 'phrase': return vPhrase();
    case 'quiz': return vQuiz();
    case 'restore': return vRestore();
    case 'pin':
    case 'pin2': return vObPin();
    case 'sendpw': return vSendPw();
    case 'lock': return vLock();
    case 'app': return vApp();
  }
  return '';
}

// ================================================================ onboarding
function vWelcome() {
  return `<div class="pad"><div style="height:36px"></div><div class="logo"><i></i></div>
  <h1>Void Wallet</h1>
  <p class="sub" style="margin-bottom:24px">A private wallet for Bitcoin, Ethereum, Tron, Solana, XRP and Stellar. Your keys stay in this browser.</p>
  ${S.libErr ? notice('The crypto libraries could not load, so a wallet cannot be created yet: ' + S.libErr, 'bad') : ''}
  ${notice('The web version runs on TEST networks only. Test coins have no value. Use the Android app for real money.', 'info')}
  ${btn('ob-create', 'Create a new wallet')}
  ${btn('ob-restore', 'I already have a recovery phrase', 'ghost')}</div>`;
}
function vPhrase() {
  const w = OB.mnemonic.split(' ');
  return `<div class="pad"><h1>Your recovery phrase</h1>
  <p class="sub">Write these ${w.length} words on paper, in order. They are the only way to get your money back if you lose this browser's data.</p>
  ${notice('Never share these words, never type them into a website, and never keep a photo of them. Anyone who has them can take everything.', 'bad')}
  <div class="card mb18"><div class="words">${w.map((x, i) => `<span><b>${i + 1}.</b> ${esc(x)}</span>`).join('')}</div></div>
  ${btn('ob-phrase-next', 'I have written them down')}</div>`;
}
function vQuiz() {
  return `<div class="pad"><h1>Quick check</h1><p class="sub">Type the words you wrote down, to prove the backup is right.</p>
  ${OB.quiz.map((p, i) => `<label class="lbl" for="q${i}">Word #${p + 1}</label><input class="field" id="q${i}" autocapitalize="none" autocomplete="off" spellcheck="false">`).join('')}
  ${OB.err ? notice(OB.err, 'bad') : ''}
  ${btn('ob-quiz-next', 'Continue')}
  ${btn('ob-quiz-back', 'Show the phrase again', 'ghost')}</div>`;
}
function vRestore() {
  return `<div class="pad"><h1>Restore wallet</h1><p class="sub">Enter your 12 or 24 recovery words, separated by spaces.</p>
  <textarea class="field" id="mn" placeholder="word1 word2 word3 ..." autocapitalize="none" autocomplete="off" spellcheck="false">${esc(OB.mnText || '')}</textarea>
  ${OB.err ? notice(OB.err, 'bad') : ''}
  ${btn('ob-restore-next', 'Continue', 'primary', OB.busy ? 'disabled' : '')}
  ${btn('ob-welcome', 'Back', 'ghost')}</div>`;
}
function vObPin() {
  const first = S.screen === 'pin';
  return pinScreen(
    first ? 'Choose a 6-digit PIN' : 'Repeat your PIN',
    first ? 'You will need it to open the wallet. After 5 wrong tries the wallet is erased from this browser.' : 'Enter the same PIN again.',
    (p) => {
      if (first) { OB.pin = p; OB.err = null; go('pin2'); }
      else if (p === OB.pin) { OB.err = null; go('sendpw'); }
      else { OB.err = 'The PINs did not match. Try again.'; OB.pin = ''; go('pin'); }
    },
    OB.err
  );
}
function vSendPw() {
  return `<div class="pad"><h1>Send password</h1>
  <p class="sub">A second password, different from your PIN. It is asked every time you send money, so someone who learns your PIN still cannot move your funds.</p>
  <label class="lbl" for="pw1">Send password (8+ characters)</label><input class="field" id="pw1" type="password" autocomplete="new-password">
  <label class="lbl" for="pw2">Repeat send password</label><input class="field" id="pw2" type="password" autocomplete="new-password">
  ${OB.err ? notice(OB.err, 'bad') : ''}
  ${btn('ob-finish', OB.saving ? spinner : 'Create wallet', 'primary', OB.saving ? 'disabled' : '')}</div>`;
}

async function finishOnboarding() {
  const pw = val('pw1');
  if (pw.length < 8) return fail('The send password needs at least 8 characters.');
  if (pw !== val('pw2')) return fail('The two passwords do not match.');
  if (pw === OB.pin) return fail('The send password must differ from your PIN.');
  function fail(m) { OB.err = m; render(); }
  OB.saving = true;
  OB.err = null;
  render();
  try {
    await V.saveVault('main', OB.pin, OB.mnemonic);
    await V.setSendPassword('main', pw);
    await V.setFails(0);
    const cfg = DEF();
    cfg.backedUp = true;
    cfg.needsScan = !!OB.restore;
    localStorage.setItem('vw_state_main', JSON.stringify(cfg));
    const m = OB.mnemonic;
    OB = {};
    await unlock('main', m);
  } catch (e) {
    OB.saving = false;
    OB.err = 'Could not save the wallet: ' + msg(e);
    render();
  }
}

// ================================================================ lock
function vLock() {
  return pinScreen('Void Wallet', padBusy ? 'Unlocking…' : 'Enter your PIN', attemptUnlock, S.lockMsg, '');
}
async function attemptUnlock(pin) {
  if (padBusy) return;
  padBusy = true;
  try {
    const fails = (await V.getFails()) + 1;
    await V.setFails(fails); // counted before checking, so closing the page mid-check cannot reset it
    const r = await V.tryUnlock(pin);
    if (r) {
      await V.setFails(0);
      S.lockMsg = null;
      await unlock(r.ns, r.mnemonic);
      return;
    }
    if (fails >= V.MAX_FAILS) {
      await V.wipeAll();
      S.lockMsg = null;
      Object.assign(S, { cfg: DEF(), mnemonic: '', seed: null });
      go('welcome');
      return;
    }
    const left = V.MAX_FAILS - fails;
    S.lockMsg = left === 1 ? 'Wrong PIN. 1 attempt left. After that the wallet is erased from this browser.' : `Wrong PIN. ${left} attempts left.`;
    render();
  } catch (e) {
    S.lockMsg = 'Could not open the wallet: ' + msg(e);
    render();
  } finally {
    padBusy = false;
  }
}

async function unlock(ns, mnemonic) {
  S.ns = ns;
  S.mnemonic = mnemonic;
  addrCache.clear();
  Object.keys(lastTotals).forEach((k) => delete lastTotals[k]);
  let cfg = DEF();
  try {
    const raw = localStorage.getItem('vw_state_' + ns);
    if (raw) cfg = { ...DEF(), ...JSON.parse(raw) };
  } catch {}
  if (ns === 'decoy') cfg.backedUp = true;
  if (!ALLOW_MAIN) cfg.net = 'test';
  S.cfg = cfg;
  S.seed = await L.seedFromMnemonic(mnemonic);
  Object.assign(S, { addrs: {}, bals: {}, prices: {}, errors: {}, banner: null, tab: 'wallet', ov: null, sub: null, picking: null, note: null });
  go('app');
  refresh();
  clearInterval(timer);
  timer = setInterval(() => { if (document.visibilityState === 'visible') refresh(); }, 60000);
}

function lockNow() {
  clearInterval(timer);
  S.mnemonic = '';
  S.seed = null;
  addrCache.clear();
  Object.assign(S, { addrs: {}, bals: {}, prices: {}, ov: null, sub: null, picking: null });
  SD = {}; R = {};
  ovStack.length = 0;
  S.lockMsg = null;
  go('lock');
}

// ================================================================ addresses, balances, prices
async function derive() {
  const net = S.cfg.net;
  const out = {};
  const errs = { ...S.errors };
  await Promise.all(LIVE_COINS.map(async (coin) => {
    const n = (S.cfg.index[`${net}:${coin}`] ?? 0) + 1;
    const list = [];
    try {
      for (let i = 0; i < n; i++) {
        const k = `${net}:${coin}:${i}`;
        if (!addrCache.has(k)) addrCache.set(k, await L.addressAt(coin, S.seed, net, i));
        list.push(addrCache.get(k));
      }
      if (errs[coin] && errs[coin].startsWith('Could not load')) delete errs[coin];
    } catch (e) {
      errs[coin] = 'Could not load ' + coin + ': ' + msg(e);
    }
    out[coin] = list;
  }));
  S.addrs = out;
  S.errors = errs;
}

async function scanUsed() {
  const net = S.cfg.net;
  const next = { ...S.cfg.index };
  await Promise.all(LIVE_COINS.map(async (coin) => {
    const gap = coin === 'BTC' ? 8 : 3;
    let lastUsed = -1, misses = 0;
    try {
      for (let i = 0; i < 40 && misses < gap; i++) {
        const a = await L.addressAt(coin, S.seed, net, i);
        if (await L.addressUsed(coin, nodeFor(coin), a)) { lastUsed = i; misses = 0; } else misses++;
      }
    } catch {}
    next[`${net}:${coin}`] = Math.max(0, lastUsed);
  }));
  patch({ index: next, needsScan: false });
}

async function refresh() {
  if (S.refreshing || !S.seed) return;
  S.refreshing = true;
  softRender();
  const net = S.cfg.net;
  try {
    if (S.cfg.needsScan) await scanUsed();
    await derive();
    const errs = {};
    const next = {};
    await Promise.all(LIVE_COINS.map(async (coin) => {
      const list = S.addrs[coin] || [];
      if (!list.length) { if (S.errors[coin]) errs[coin] = S.errors[coin]; next[coin] = []; return; }
      try {
        next[coin] = await L.fetchBalances(coin, nodeFor(coin), list);
      } catch (e) {
        errs[coin] = msg(e).slice(0, 160);
        const old = S.bals[coin] || [];
        next[coin] = list.map((_, i) => old[i] ?? 0n); // keep the last known balance if a server fails
      }
    }));
    if (!S.seed || S.cfg.net !== net) return;
    S.errors = errs;
    S.bals = next;
    for (const coin of LIVE_COINS) {
      if (errs[coin]) continue;
      const total = next[coin].reduce((a, b) => a + b, 0n);
      const k = `${net}:${coin}`;
      if (lastTotals[k] !== undefined && total > lastTotals[k]) {
        const delta = total - lastTotals[k];
        S.banner = `Received ${formatUnits(delta, COINS[coin].decimals)} ${coin}`;
        addHistory({ kind: 'received', coin, amount: delta.toString() });
      }
      lastTotals[k] = total;
    }
    if (net === 'main') {
      try {
        const ids = LIVE_COINS.map((c) => COINS[c].coingecko).join(',');
        const res = await fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${ids}&vs_currencies=usd&include_24hr_change=true`);
        if (!res.ok) throw new Error('price feed ' + res.status);
        const j = await res.json();
        const pm = {};
        for (const c of LIVE_COINS) {
          const r = j[COINS[c].coingecko];
          if (r && r.usd != null) pm[c] = { usd: r.usd, change: r.usd_24h_change ?? 0 };
        }
        S.prices = pm;
        S.priceStale = false;
      } catch {
        S.priceStale = true;
      }
    }
  } finally {
    S.refreshing = false;
    softRender();
  }
}

function addHistory(h) {
  S.cfg.history = [{ ...h, id: `${Date.now()}-${h.coin}`, t: Date.now(), net: S.cfg.net }, ...S.cfg.history].slice(0, 300);
  saveCfg();
}
async function newAddress(coin) {
  const k = key(coin);
  S.cfg.index[k] = (S.cfg.index[k] ?? 0) + 1;
  saveCfg();
  await derive();
}
async function bumpIndexTo(coin, idx) {
  const k = key(coin);
  if ((S.cfg.index[k] ?? 0) < idx) { S.cfg.index[k] = idx; saveCfg(); await derive(); }
}

// ================================================================ app shell
function vApp() {
  if (S.ov) {
    if (S.ov.kind === 'send') return vSend();
    if (S.ov.kind === 'receive') return vReceive();
    return vCoin();
  }
  const body = S.tab === 'wallet' ? vHome() : S.tab === 'swap' ? vSwap() : vSettings();
  const tab = (id, label, icon) =>
    `<button class="tab ${S.tab === id ? 'on' : ''}" data-act="tab" data-tab="${id}">${icon}${label}</button>`;
  const hideTabs = S.tab === 'settings' && S.sub && S.sub.kind === 'pin-ish';
  return `<div class="body">${body}</div>${hideTabs ? '' : `<nav class="tabs">${tab('wallet', 'Wallet', ico.wallet)}${tab('swap', 'Swap', ico.swap)}${tab('settings', 'Settings', ico.gear)}</nav>`}`;
}

function vHome() {
  const c = S.cfg, isTest = c.net === 'test', hide = c.hide, dots = '•••••';
  const usdTotal = isTest ? 0 : LIVE_COINS.reduce((s, k) => (S.prices[k] ? s + toUsd(totalOf(k), COINS[k].decimals, S.prices[k].usd) : s), 0);
  const sub = isTest ? 'Test coins have no value' : S.priceStale ? 'Prices may be out of date' : 'Excludes Monero (coming later)';
  const rows = LIVE_COINS.map((coin) => {
    const price = S.prices[coin];
    const bal = totalOf(coin);
    const usd = price && !isTest ? toUsd(bal, COINS[coin].decimals, price.usd) : null;
    return `<div class="card coin" data-act="open-coin" data-coin="${coin}" role="button" tabindex="0">
      <div class="row between"><div class="row gap12">${avatar(coin)}<div><div class="name">${COINS[coin].name}</div>
        <div class="small">${!isTest && price ? `${fmtUsd(price.usd)} <span class="${price.change >= 0 ? 'up' : 'down'}">${price.change >= 0 ? '+' : ''}${price.change.toFixed(2)}%</span>` : '&nbsp;'}</div></div></div>
        <div class="right"><div class="name num">${hide ? dots : formatUnits(bal, COINS[coin].decimals, 6)}</div>
        <div class="small num">${hide ? dots : usd !== null ? fmtUsd(usd) : isTest ? 'test' : '—'}</div></div></div>
      ${S.errors[coin] ? `<div class="small warn" style="margin-top:8px">${esc(S.errors[coin].startsWith('Could not load') ? S.errors[coin] : "Can't reach the " + coin + ' server. Showing the last known balance.')}</div>` : ''}
    </div>`;
  }).join('');
  return `<div class="pad">
  <div class="row between mb18"><div style="font-size:20px;font-weight:800">Void Wallet</div>
    <div class="row gap12">${isTest ? '<span class="pill warn">TESTNET</span>' : ''}
      <button class="ibtn" data-act="refresh" aria-label="Refresh">${S.refreshing ? spinner : ico.refresh}</button>
      <button class="ibtn" data-act="hide" aria-label="Show or hide balances">${hide ? ico.eyeOff : ico.eye}</button>
      <button class="ibtn" data-act="lock" aria-label="Lock">${ico.lock}</button></div></div>
  ${S.banner ? `<div class="notice info" data-act="dismiss" role="button">${esc(S.banner)} (tap to dismiss)</div>` : ''}
  ${!c.backedUp ? notice('Back up your recovery phrase: Settings → View recovery phrase.') : ''}
  <div class="grad"><div class="t">Total balance</div><div class="v">${hide ? '$ •••••' : isTest ? 'Test coins' : fmtUsd(usdTotal)}</div><div class="n">${sub}</div></div>
  <div class="row gap12 mb18"><button class="act ${S.picking === 'send' ? 'on' : ''}" data-act="pick" data-k="send">↑  Send</button>
    <button class="act ${S.picking === 'receive' ? 'on' : ''}" data-act="pick" data-k="receive">↓  Receive</button></div>
  ${S.picking ? `<div class="card mb18"><div class="small mb8">Choose a coin to ${S.picking}</div><div class="row gap8" style="flex-wrap:wrap">
    ${LIVE_COINS.map((k) => `<button class="chip" style="border-color:${COINS[k].color}" data-act="pick-coin" data-coin="${k}">${k}</button>`).join('')}</div></div>` : ''}
  ${rows}
  <div class="card" style="opacity:.6"><div class="row gap12">${avatar('XMR')}<div><div class="name">Monero</div><div class="small">Coming in phase 3</div></div></div></div>
  </div>`;
}

function vSwap() {
  return `<div class="pad"><h1>Swap</h1>
  <p class="sub">Swapping between your coins arrives in phase 2. It will ask several exchange services for a rate and show you the best one, with fees, the minimum amount and the estimated time.</p>
  <div class="card mb14"><div class="name mb8">Coming next</div><div class="sub" style="margin:0">Compare providers · see fees before you confirm · send with your send password · Monero swaps in phase 3.</div></div>
  ${notice('Nothing here moves any money yet.', 'info')}</div>`;
}

// ================================================================ coin detail
const ovStack = [];
function openOv(ov) {
  if (S.ov) ovStack.push(S.ov);
  history.pushState({ ov: 1 }, '');
  S.ov = ov;
  render();
  window.scrollTo(0, 0);
}
function popOv() {
  S.ov = ovStack.pop() || null;
  render();
}
function closeOv() {
  if (history.state && history.state.ov) history.back();
  else popOv();
}
window.addEventListener('popstate', () => {
  if (S.screen === 'app' && S.ov) popOv();
});

function vCoin() {
  const coin = S.ov.coin, m = COINS[coin], c = S.cfg, hide = c.hide;
  const bal = totalOf(coin), price = S.prices[coin];
  const items = c.history.filter((h) => h.coin === coin && h.net === c.net);
  return `<div class="pad">${bar('', 'close')}
  <div class="row gap12 mb18">${avatar(coin, true)}<h1 style="margin:0">${m.name}</h1></div>
  <div class="card mb14"><div class="small">Balance</div><div style="font-size:28px;font-weight:800;margin-top:4px" class="num">${hide ? '•••••' : formatUnits(bal, m.decimals, 8) + ' ' + coin}</div>
    <div class="small num">${hide ? '•••••' : c.net === 'test' ? 'Test coins' : price ? fmtUsd(toUsd(bal, m.decimals, price.usd)) : '—'}</div>
    ${S.errors[coin] ? `<div class="small warn" style="margin-top:8px">Server problem: ${esc(S.errors[coin])}</div>` : ''}</div>
  <div class="btns mb18"><button class="btn primary" data-act="go-send" data-coin="${coin}">Send</button><button class="btn ghost" data-act="go-receive" data-coin="${coin}">Receive</button></div>
  ${(S.addrs[coin] || []).length > 1 ? notice(`Your ${coin} is spread over ${S.addrs[coin].length} addresses (a new one is used after each payment). ${coin === 'BTC' ? 'Bitcoin sends combine them automatically.' : 'A send comes from one address at a time, the one holding the most.'}`, 'info') : ''}
  <h2>History</h2>
  ${items.length === 0 ? '<p class="sub">Nothing here yet. Payments sent from this wallet, and payments detected while it is open, appear here.</p>' :
    items.map((h) => `<div class="card mb8"><div class="row between"><div><div class="${h.kind === 'received' ? 'up' : ''}" style="font-weight:700">${h.kind === 'received' ? '↓ Received' : h.kind === 'swap' ? '⇄ Swap' : '↑ Sent'}</div><div class="small">${esc(new Date(h.t).toLocaleString())}</div></div>
      <div class="num" style="font-weight:700">${hide ? '•••••' : formatUnits(BigInt(h.amount), m.decimals, 8) + ' ' + coin}</div></div>
      ${h.txid ? `<a href="${esc(explorerUrl(coin, h.net, h.txid))}" target="_blank" rel="noopener noreferrer" class="small" style="display:block;margin-top:8px">View on block explorer ↗</a>` : ''}</div>`).join('')}
  <p class="small" style="margin-top:10px">This list is stored only in this browser. The blockchain keeps its own permanent record that cannot be erased.</p></div>`;
}

// ================================================================ receive
let qrLoading = null;
function loadQR() {
  if (window.qrcode) return Promise.resolve(true);
  if (!qrLoading) qrLoading = new Promise((res) => {
    const s = document.createElement('script');
    s.src = 'https://cdnjs.cloudflare.com/ajax/libs/qrcode-generator/1.4.4/qrcode.min.js';
    s.onload = () => res(true);
    s.onerror = () => { qrLoading = null; res(false); };
    document.head.appendChild(s);
  });
  return qrLoading;
}
function qrSvg(text) {
  try {
    const q = window.qrcode(0, 'M');
    q.addData(text); q.make();
    const n = q.getModuleCount();
    let d = '';
    for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (q.isDark(r, c)) d += `M${c} ${r}h1v1h-1z`;
    return `<svg viewBox="0 0 ${n} ${n}" shape-rendering="crispEdges" role="img" aria-label="QR code of the address"><path d="${d}" fill="#000"/></svg>`;
  } catch { return ''; }
}

async function openReceive(coin) {
  R = { coin, used: null, qr: '' };
  openOv({ kind: 'receive', coin });
  await checkReceive(coin);
}
async function checkReceive(coin) {
  const stillHere = () => S.ov && S.ov.kind === 'receive' && S.ov.coin === coin;
  for (let round = 0; round < 6 && stillHere(); round++) {
    const idx = curIdx(coin);
    let address = (S.addrs[coin] || [])[idx];
    if (!address) { await derive(); address = (S.addrs[coin] || [])[idx]; }
    if (!address) { render(); return; }
    R.qr = (await loadQR()) ? qrSvg(address) : '';
    if (!stillHere()) return;
    let used = (S.bals[coin] && S.bals[coin][idx] || 0n) > 0n;
    if (!used) { try { used = await L.addressUsed(coin, nodeFor(coin), address); } catch {} }
    if (!stillHere()) return;
    R.used = used;
    if (!(used && S.cfg.fresh[coin])) render();
    // A fresh address is issued only after the previous one received something, so the number of
    // unused addresses stays at zero and restoring from the phrase never misses funds.
    if (used && S.cfg.fresh[coin]) { await newAddress(coin); R.used = null; continue; }
    return;
  }
}
function vReceive() {
  const coin = S.ov.coin, m = COINS[coin], idx = curIdx(coin);
  const address = (S.addrs[coin] || [])[idx] || '';
  const fresh = S.cfg.fresh[coin];
  return `<div class="pad">${bar('', 'close')}<h1>Receive ${m.name}</h1>
  <p class="sub">Only send ${coin} to this address, on the ${S.cfg.net === 'test' ? 'TEST' : 'main'} network.</p>
  ${S.cfg.net === 'test' ? notice('Test mode: use a faucet to get free test coins. They have no value.', 'info') : ''}
  ${coin === 'XRP' ? notice('XRP addresses must first receive a minimum amount (the network reserve, about 1 XRP) before they work. That reserve stays locked in the address.') : ''}
  ${coin === 'XLM' ? notice('A Stellar address must first receive a minimum amount (about 1 XLM) before it works. That amount stays locked in the address. Exchanges may also need you to give them a memo.') : ''}
  ${coin === 'TRX' ? notice('A new Tron address is activated by its first incoming payment. The sender pays a small activation fee.') : ''}
  ${S.errors[coin] && !address ? notice(S.errors[coin], 'bad') : ''}
  <div class="card center mb18">${R.qr ? `<div class="qr">${R.qr}</div>` : ''}
    <div class="addr" style="margin-top:${R.qr ? 16 : 0}px">${esc(address)}</div>
    <div style="margin-top:10px"><span class="pill">${fresh ? `Address #${idx + 1} · new one after each payment` : `Address #${idx + 1} · reused`}</span></div></div>
  ${btn('copy', 'Copy address', 'primary', `data-text="${esc(address)}" ${address ? '' : 'disabled'}`)}
  ${!fresh && R.used ? btn('new-addr', 'Get a new address', 'ghost', `data-coin="${coin}"`) : ''}
  ${R.used === false ? '<p class="small" style="margin-top:14px">This address has not received anything yet. A new one unlocks after it does, so your wallet can always be fully restored from the recovery phrase.</p>' : ''}
  ${btn('close', 'Back', 'ghost')}</div>`;
}

// ================================================================ send
function openSend(coin) {
  SD = { coin, phase: 'form', to: '', amount: '', tag: '', max: false, level: 'normal', err: null, working: false, prepared: null, pwFails: 0, txid: null };
  openOv({ kind: 'send', coin });
}
function readSendFields() {
  if (SD.phase !== 'form') return;
  if ($('s_to')) SD.to = val('s_to');
  if ($('s_amt') && !SD.max) SD.amount = val('s_amt');
  if ($('s_tag')) SD.tag = val('s_tag');
}
function vSend() {
  const coin = SD.coin, m = COINS[coin];
  const hasTag = coin === 'XRP' || coin === 'XLM';
  if (SD.phase === 'done') {
    return `<div class="pad"><h1>Sent ✓</h1><p class="sub">Your transaction was submitted to the network. It can take a little while to confirm.</p>
    ${SD.txid ? `<a href="${esc(explorerUrl(coin, S.cfg.net, SD.txid))}" target="_blank" rel="noopener noreferrer" style="display:block;margin-bottom:20px">View on block explorer ↗</a>` : ''}
    ${btn('close', 'Done')}</div>`;
  }
  if ((SD.phase === 'review' || SD.phase === 'sending') && SD.prepared) {
    const p = SD.prepared;
    const price = S.prices[coin];
    const usd = S.cfg.net === 'main' && price ? fmtUsd(toUsd(p.amount, m.decimals, price.usd)) : null;
    return `<div class="pad"><h1>Confirm</h1>
    ${S.cfg.net === 'test' ? notice('TEST network. These coins have no value.', 'info') : ''}
    <div class="card mb14"><span class="lbl">You send</span><div style="font-size:26px;font-weight:800" class="num">${formatUnits(p.amount, m.decimals, 8)} ${coin}</div>
      ${usd ? `<div class="small">≈ ${usd}</div>` : ''}
      <span class="lbl" style="margin-top:14px">To (check every character)</span><div class="addr">${esc(SD.to.trim())}</div>
      ${hasTag && SD.tag.trim() ? `<div class="small" style="margin-top:4px">${coin === 'XLM' ? 'Memo' : 'Destination tag'}: ${esc(SD.tag.trim())}</div>` : ''}
      <span class="lbl" style="margin-top:14px">Network fee</span><div>${esc(p.feeText)}</div></div>
    ${p.notes.map((n) => notice(n)).join('')}
    <label class="lbl" for="s_pw">Send password</label><input class="field" id="s_pw" type="password" autocomplete="current-password">
    ${SD.err ? notice(SD.err, 'bad') : ''}
    ${btn('s-confirm', SD.working || SD.phase === 'sending' ? spinner : 'Confirm and send', 'primary', SD.working || SD.phase === 'sending' ? 'disabled' : '')}
    ${btn('s-cancel', 'Cancel', 'ghost', SD.phase === 'sending' ? 'disabled' : '')}
    <p class="sub" style="margin-top:12px">Crypto transfers cannot be undone.</p></div>`;
  }
  const total = totalOf(coin);
  return `<div class="pad">${bar('', 'close')}<h1>Send ${m.name}</h1>
  <p class="sub">Balance: ${formatUnits(total, m.decimals, 8)} ${coin}</p>
  <label class="lbl" for="s_to">Recipient address</label><input class="field" id="s_to" placeholder="${m.name} address" value="${esc(SD.to)}" autocomplete="off" spellcheck="false">
  <label class="lbl" for="s_amt">Amount (${coin})</label><input class="field" id="s_amt" inputmode="decimal" placeholder="0.0" value="${SD.max ? 'Max' : esc(SD.amount)}" ${SD.max ? 'disabled' : ''}>
  ${L.SUPPORTS_MAX[coin] ? btn('s-max', SD.max ? 'Use a fixed amount' : 'Send everything (Max)', 'ghost slim', 'style="margin:-4px 0 14px"') : ''}
  ${hasTag ? `<label class="lbl" for="s_tag">${coin === 'XLM' ? 'Memo (needed by most exchanges)' : 'Destination tag (needed by most exchanges)'}</label><input class="field" id="s_tag" value="${esc(SD.tag)}" ${coin === 'XRP' ? 'inputmode="numeric"' : ''} autocomplete="off">` : ''}
  ${L.SUPPORTS_FEE_LEVEL[coin] ? `<span class="lbl">Speed</span><div class="seg">${['slow', 'normal', 'fast'].map((l) => `<button class="${SD.level === l ? 'on' : ''}" data-act="s-level" data-l="${l}">${l}</button>`).join('')}</div>` : ''}
  ${SD.err ? notice(SD.err, 'bad') : ''}
  ${btn('s-review', SD.working ? spinner : 'Review', 'primary', SD.working ? 'disabled' : '')}
  ${btn('close', 'Back', 'ghost')}</div>`;
}

async function sendReview() {
  readSendFields();
  SD.err = null;
  const coin = SD.coin, m = COINS[coin], dest = SD.to.trim(), net = S.cfg.net;
  if (!dest) { SD.err = 'Enter the recipient address.'; return render(); }
  let amount;
  if (SD.max) amount = 'max';
  else {
    amount = parseUnits(SD.amount, m.decimals);
    if (amount === null) { SD.err = 'Enter a valid amount.'; return render(); }
  }
  SD.working = true;
  render();
  try {
    if (!(await L.validateAddress(coin, net, dest))) throw new Error(`That is not a valid ${m.name} address for the ${net === 'test' ? 'test' : 'main'} network.`);
    const accounts = (S.addrs[coin] || []).map((address, index) => ({ index, address, balance: (S.bals[coin] && S.bals[coin][index]) || 0n }));
    SD.prepared = await L.prepareSend({ coin, seed: S.seed, net, node: nodeFor(coin), accounts, nextIndex: accounts.length, to: dest, amount, level: SD.level, tag: SD.tag });
    SD.phase = 'review';
  } catch (e) {
    SD.err = msg(e);
  } finally {
    SD.working = false;
    render();
  }
}
async function sendConfirm() {
  const pw = val('s_pw');
  if (!pw) return;
  SD.err = null;
  SD.working = true;
  render();
  const ok = await V.checkSendPassword(S.ns, pw);
  if (!ok) {
    SD.pwFails++;
    SD.working = false;
    if (SD.pwFails >= 5) return lockNow();
    SD.err = `Wrong send password. ${5 - SD.pwFails} tries left before the wallet locks.`;
    return render();
  }
  SD.phase = 'sending';
  render();
  try {
    const p = SD.prepared;
    const res = await p.execute();
    addHistory({ kind: 'sent', coin: SD.coin, amount: p.amount.toString(), to: SD.to.trim(), txid: res.txid || undefined });
    if (res.usedIndex !== undefined) await bumpIndexTo(SD.coin, res.usedIndex);
    SD.txid = res.txid || null;
    SD.phase = 'done';
    setTimeout(refresh, 4000);
  } catch (e) {
    SD.err = msg(e);
    SD.phase = 'review';
  }
  SD.working = false;
  render();
}

// ================================================================ settings
function vSettings() {
  const sub = S.sub;
  if (sub) return vSub(sub);
  const c = S.cfg;
  return `<div class="pad"><h1>Settings</h1>
  ${S.note ? notice(S.note, 'info') : ''}
  <div class="sec">Network</div><div class="card">
    <div class="row between"><div style="flex:1;padding-right:12px"><div style="font-weight:600">Use test networks</div>
      <div class="small">${ALLOW_MAIN ? 'Test coins have no value. Turn off for real money.' : 'The web version works on test networks only. Use the Android app for real money.'}</div></div>
      ${switchEl('toggle-net', c.net === 'test', ALLOW_MAIN ? '' : 'disabled')}</div>
    <button class="link" data-act="sub" data-k="nodes">Nodes / servers  ›</button></div>
  <div class="sec">Privacy</div><div class="card">
    <div class="small mb8">New address after each payment (the previous one must have received something first).</div>
    ${LIVE_COINS.map((k) => `<div class="row between" style="margin-bottom:8px"><div style="flex:1;padding-right:10px">${COINS[k].name}
      ${k === 'XRP' || k === 'XLM' ? `<div class="small">Off by default: every ${k} address locks a reserve (about 1 ${k}).</div>` : ''}</div>${switchEl('toggle-fresh', c.fresh[k], `data-coin="${k}"`)}</div>`).join('')}
    <div class="small" style="margin-top:8px">Tor and Monero privacy tools are planned for later phases. This build connects to servers directly from your browser, so they can see your IP address.</div></div>
  <div class="sec">Security</div><div class="card">
    <button class="link" data-act="sub" data-k="phrase">View recovery phrase  ›</button>
    <button class="link" data-act="sub" data-k="changePin">Change PIN  ›</button>
    <button class="link" data-act="sub" data-k="changeSendPw">Change send password  ›</button>
    ${S.ns === 'main' ? '<button class="link" data-act="sub" data-k="decoy">Decoy wallet PIN (optional)  ›</button>' : ''}</div>
  <div class="sec">Data in this browser</div><div class="card">
    ${btn('sub', 'Clear history and cached data', 'ghost', 'data-k="clear"')}
    ${btn('sub', 'Erase wallet from this browser', 'danger', 'data-k="erase"')}</div>
  <div class="sec">About</div><div class="card small" style="line-height:1.5">Void Wallet · web version (test networks). Bitcoin, Ethereum, Tron, Solana, XRP and Stellar. Swaps and Monero are still to come. Not audited. The PIN protection in a browser is weaker than in the Android app, so do not keep anything of value here. No fingerprint unlock in the web version.</div></div>`;
}

function vSub(sub) {
  const back = btn('sub-back', 'Back', 'ghost');
  switch (sub.kind) {
    case 'nodes':
      return `<div class="pad">${bar('', 'sub-back')}<h1>Servers</h1>
      <p class="sub">Using the ${S.cfg.net === 'test' ? 'test' : 'main'} network. Leave blank for the default. Use your own server for better privacy. Plain http:// is not encrypted, and browsers block it on https pages.</p>
      ${LIVE_COINS.map((k) => `<label class="lbl" for="n_${k}">${COINS[k].name}</label><input class="field" id="n_${k}" placeholder="${esc(DEFAULT_NODES[S.cfg.net][k])}" value="${esc(S.cfg.nodes[key(k)] || '')}" autocomplete="off" spellcheck="false">`).join('')}
      <p class="small mb14">Bitcoin needs a mempool.space-compatible API. Ethereum needs a JSON-RPC URL. Tron needs a TronGrid-style API. Solana and XRP need their JSON-RPC URL. Stellar needs a Horizon server URL. The server must allow requests from web pages (CORS).</p>
      ${sub.err ? notice(sub.err, 'bad') : ''}${btn('nodes-save', 'Save')}${back}</div>`;
    case 'phrase': {
      if (!sub.shown) return pinScreen('Enter your PIN', 'To show your recovery phrase.', async (p) => {
        if (await verifyPin(p)) { sub.shown = true; sub.err = null; render(); } else { sub.err = 'Wrong PIN.'; render(); }
      }, sub.err, `<div style="margin-top:14px">${back}</div>`);
      return `<div class="pad"><h1>Recovery phrase</h1>${notice('Anyone who sees these words can take your money. Make sure nobody is watching.', 'bad')}
      <div class="card mb18"><div class="words">${S.mnemonic.split(' ').map((x, i) => `<span><b>${i + 1}.</b> ${esc(x)}</span>`).join('')}</div></div>${btn('sub-back', 'Hide and go back')}</div>`;
    }
    case 'changePin': {
      const t = { old: 'Enter your current PIN', new: 'Choose a new PIN', new2: 'Repeat the new PIN' }[sub.stage];
      return pinScreen(t, '', async (p) => {
        if (sub.stage === 'old') {
          if (await verifyPin(p)) { sub.old = p; sub.err = null; sub.stage = 'new'; } else sub.err = 'Wrong PIN.';
        } else if (sub.stage === 'new') {
          if (p === sub.old) sub.err = 'The new PIN must be different.';
          else if ((await V.tryUnlock(p)) !== null) sub.err = 'That PIN is already used by a wallet in this browser.';
          else { sub.nw = p; sub.err = null; sub.stage = 'new2'; }
        } else if (p === sub.nw) {
          if (!(await V.changePin(S.ns, sub.old, sub.nw))) { sub.err = 'Could not change the PIN.'; sub.stage = 'old'; }
          else { S.sub = null; S.note = 'PIN changed.'; }
        } else { sub.err = 'PINs did not match.'; sub.stage = 'new'; }
        render();
      }, sub.err, `<div style="margin-top:14px">${back}</div>`);
    }
    case 'changeSendPw':
      return `<div class="pad">${bar('', 'sub-back')}<h1>Change send password</h1>
      <label class="lbl" for="c_old">Current send password</label><input class="field" id="c_old" type="password" autocomplete="current-password">
      <label class="lbl" for="c_new">New send password (8+ characters)</label><input class="field" id="c_new" type="password" autocomplete="new-password">
      <label class="lbl" for="c_new2">Repeat new send password</label><input class="field" id="c_new2" type="password" autocomplete="new-password">
      ${sub.err ? notice(sub.err, 'bad') : ''}${btn('sendpw-save', 'Change')}${back}</div>`;
    case 'decoy': return vDecoy(sub, back);
    case 'clear':
      return `<div class="pad">${bar('', 'sub-back')}<h1>Clear history?</h1><p class="sub">Removes the transaction list, swap records and cached balances from this browser. Your keys and recovery phrase are not touched. The blockchain keeps its own permanent record.</p>${btn('clear-yes', 'Clear')}${back}</div>`;
    case 'erase':
      return `<div class="pad">${bar('', 'sub-back')}<h1>Erase this wallet?</h1>${notice('This deletes the wallet from this browser. You can only get your money back with your recovery phrase. Make sure you have it.', 'bad')}${btn('erase-yes', 'Erase wallet', 'danger')}${back}</div>`;
  }
  return '';
}

function vDecoy(sub, back) {
  if (sub.exists === null) return `<div class="pad center"><div class="spin" style="margin:40vh auto 0"></div></div>`;
  if (sub.exists) {
    return `<div class="pad">${bar('', 'sub-back')}<h1>Decoy wallet</h1><p class="sub">A decoy PIN is set. Typing it opens a separate wallet instead of your real one.</p>
    ${btn('decoy-remove', 'Remove decoy wallet', 'danger')}${back}</div>`;
  }
  if (sub.stage === 'info') {
    return `<div class="pad">${bar('', 'sub-back')}<h1>Decoy wallet</h1><p class="sub">A second PIN that opens a separate, empty wallet, in case someone forces you to unlock your phone.</p>
    ${notice('The decoy wallet is real and separate. It has its own recovery phrase and starts empty. Put a small amount in it so it looks believable. Nothing is faked.')}
    ${btn('decoy-start', 'Set up decoy PIN')}${back}</div>`;
  }
  if (sub.stage === 'pin' || sub.stage === 'pin2') {
    return pinScreen(sub.stage === 'pin' ? 'Choose a decoy PIN' : 'Repeat the decoy PIN', 'It must be different from your real PIN.', async (p) => {
      if (sub.stage === 'pin') {
        if (await V.pinMatchesMain(p)) sub.err = 'That is your real PIN. Choose a different one.';
        else { sub.err = null; sub.pin = p; sub.stage = 'pin2'; }
      } else if (p === sub.pin) { sub.err = null; sub.stage = 'pw'; }
      else { sub.err = 'PINs did not match.'; sub.stage = 'pin'; }
      render();
    }, sub.err, `<div style="margin-top:14px">${back}</div>`);
  }
  return `<div class="pad"><h1>Decoy send password</h1><p class="sub">The decoy wallet needs its own send password (8+ characters).</p>
  <label class="lbl" for="d_pw">Decoy send password</label><input class="field" id="d_pw" type="password" autocomplete="new-password">
  ${sub.err ? notice(sub.err, 'bad') : ''}${btn('decoy-create', 'Create decoy wallet')}${back}</div>`;
}

async function verifyPin(pin) {
  const fails = (await V.getFails()) + 1;
  await V.setFails(fails);
  const r = await V.tryUnlock(pin);
  if (r && r.ns === S.ns) { await V.setFails(0); return true; }
  if (fails >= V.MAX_FAILS) {
    await V.wipeAll();
    clearInterval(timer);
    Object.assign(S, { cfg: DEF(), mnemonic: '', seed: null, ov: null, sub: null });
    go('welcome');
  }
  return false;
}

// ================================================================ actions
const pick3 = () => {
  const s = new Set();
  while (s.size < 3) s.add(Math.floor(Math.random() * 12));
  return [...s].sort((a, b) => a - b);
};

const A = {
  async pin(d) {
    if (padBusy || pinBuf.length >= 6) return;
    if (d.d === '⌫') { pinBuf = pinBuf.slice(0, -1); return updateDots(); }
    pinBuf += d.d;
    updateDots();
    if (pinBuf.length === 6) {
      const p = pinBuf, cb = padCb;
      pinBuf = '';
      setTimeout(async () => { updateDots(); if (cb) await cb(p); }, 120);
    }
  },
  async 'ob-create'() {
    try { OB = { restore: false, mnemonic: await L.newMnemonic(12), err: null }; S.libErr = null; go('phrase'); }
    catch (e) { S.libErr = msg(e); render(); }
  },
  'ob-restore'() { OB = { restore: true, mnemonic: '', err: null }; go('restore'); },
  'ob-welcome'() { go('welcome'); },
  'ob-phrase-next'() { OB.quiz = pick3(); OB.err = null; go('quiz'); },
  'ob-quiz-back'() { go('phrase'); },
  'ob-quiz-next'() {
    const w = OB.mnemonic.split(' ');
    const ok = OB.quiz.every((p, i) => val('q' + i).trim().toLowerCase() === w[p]);
    if (!ok) { OB.err = 'One or more words are wrong. Look at your paper again.'; return render(); }
    OB.err = null; go('pin');
  },
  async 'ob-restore-next'() {
    OB.mnText = val('mn');
    OB.busy = true;
    try {
      if (!(await L.isValidMnemonic(OB.mnText))) { OB.err = 'That is not a valid recovery phrase. Check each word.'; OB.busy = false; return render(); }
      OB.mnemonic = await L.normalizeMnemonic(OB.mnText);
      OB.err = null; OB.busy = false; go('pin');
    } catch (e) { OB.err = msg(e); OB.busy = false; render(); }
  },
  'ob-finish': () => finishOnboarding(),

  lock() { lockNow(); },
  hide() { patch({ hide: !S.cfg.hide }); render(); },
  refresh() { refresh(); },
  dismiss() { S.banner = null; render(); },
  tab(d) { S.tab = d.tab; S.sub = null; S.note = null; S.picking = null; render(); window.scrollTo(0, 0); },
  pick(d) { S.picking = S.picking === d.k ? null : d.k; render(); },
  'pick-coin'(d) { const k = S.picking; S.picking = null; if (k === 'send') openSend(d.coin); else openReceive(d.coin); },
  'open-coin'(d) { openOv({ kind: 'coin', coin: d.coin }); },
  'go-send'(d) { SD = {}; openSend(d.coin); },
  'go-receive'(d) { openReceive(d.coin); },
  close() { closeOv(); },

  async copy(d, e) {
    const b = e.target.closest('button');
    const text = d.text;
    const done = () => { b.textContent = 'Copied ✓'; setTimeout(() => { b.textContent = 'Copy address'; }, 1500); };
    try { await navigator.clipboard.writeText(text); done(); }
    catch {
      const r = document.createRange(); const n = root.querySelector('.addr');
      if (n) { r.selectNodeContents(n); const s = getSelection(); s.removeAllRanges(); s.addRange(r); }
      b.textContent = 'Address selected. Press copy.';
    }
  },
  async 'new-addr'(d) { await newAddress(d.coin); R.used = null; await checkReceive(d.coin); },

  's-max'() { readSendFields(); SD.err = null; SD.max = !SD.max; render(); },
  's-level'(d) { readSendFields(); SD.err = null; SD.level = d.l; render(); },
  's-review': () => sendReview(),
  's-confirm': () => sendConfirm(),
  's-cancel'() { SD.phase = 'form'; SD.err = null; render(); },

  'toggle-fresh'(d, e) { S.cfg.fresh[d.coin] = e.target.checked; saveCfg(); },
  'toggle-net'(d, e) { if (ALLOW_MAIN) { patch({ net: e.target.checked ? 'test' : 'main' }); addrCache.clear(); S.bals = {}; refresh(); } },
  async sub(d) {
    S.note = null;
    S.sub = { kind: d.k };
    if (d.k === 'changePin') S.sub.stage = 'old';
    if (d.k === 'decoy') { S.sub.exists = null; S.sub.stage = 'info'; render(); S.sub.exists = await V.hasDecoy(); }
    render();
  },
  'sub-back'() { S.sub = null; render(); },
  'nodes-save'() {
    const nodes = { ...S.cfg.nodes };
    for (const k of LIVE_COINS) {
      const v = val('n_' + k).trim().replace(/\/+$/, '');
      if (v && !/^https?:\/\//i.test(v)) { S.sub.err = `${k}: the address must start with https://`; return render(); }
      if (v) nodes[key(k)] = v; else delete nodes[key(k)];
    }
    patch({ nodes });
    S.sub = null; S.note = 'Servers saved.'; render(); refresh();
  },
  async 'sendpw-save'() {
    const o = val('c_old'), n = val('c_new');
    if (!(await V.checkSendPassword(S.ns, o))) { S.sub.err = 'Current send password is wrong.'; return render(); }
    if (n.length < 8 || n !== val('c_new2')) { S.sub.err = 'The new passwords must match and have 8+ characters.'; return render(); }
    await V.setSendPassword(S.ns, n);
    S.sub = null; S.note = 'Send password changed.'; render();
  },
  'decoy-start'() { S.sub.stage = 'pin'; render(); },
  async 'decoy-create'() {
    const pw = val('d_pw');
    if (pw.length < 8) { S.sub.err = 'The send password needs at least 8 characters.'; return render(); }
    try {
      await V.saveVault('decoy', S.sub.pin, await L.newMnemonic(12));
      await V.setSendPassword('decoy', pw);
      S.sub = null; S.note = 'Decoy wallet created.';
    } catch (e) { S.sub.err = msg(e); }
    render();
  },
  async 'decoy-remove'() { await V.removeDecoy(); S.sub = null; S.note = 'Decoy wallet removed.'; render(); },
  async 'clear-yes'() {
    S.cfg.history = []; saveCfg();
    S.prices = {}; S.bals = {};
    Object.keys(lastTotals).forEach((k) => delete lastTotals[k]);
    S.sub = null; S.note = 'History and cached data cleared from this browser.'; render(); refresh();
  },
  async 'erase-yes'() {
    await V.wipeAll();
    clearInterval(timer);
    Object.assign(S, { cfg: DEF(), mnemonic: '', seed: null, ov: null, sub: null, addrs: {}, bals: {} });
    addrCache.clear();
    ovStack.length = 0;
    go('welcome');
  },
};

function onAct(e) {
  const el = e.target.closest('[data-act]');
  if (!el || el.disabled) return;
  if (el.tagName === 'INPUT' && e.type === 'click' && el.type === 'checkbox') { /* handled below on change */ }
  const fn = A[el.dataset.act];
  if (!fn) return;
  if (el.tagName === 'INPUT' && el.type === 'checkbox') return; // checkboxes use the change event
  Promise.resolve(fn(el.dataset, e)).catch((err) => {
    console.error(err);
    S.libErr = msg(err);
  });
}
root.addEventListener('click', onAct);
root.addEventListener('change', (e) => {
  const el = e.target;
  if (el.tagName === 'INPUT' && el.type === 'checkbox' && el.dataset.act && A[el.dataset.act]) A[el.dataset.act](el.dataset, e);
});

// lock after a minute out of sight
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden') hiddenAt = Date.now();
  else if (S.screen === 'app' && hiddenAt && Date.now() - hiddenAt > 60000) lockNow();
});

// ================================================================ boot
(async function boot() {
  try { await L.ready(); } catch (e) { S.libErr = msg(e); }
  go((await V.hasWallet()) ? 'lock' : 'welcome');
})();
