export async function getJson(url, init) {
    const res = await fetch(url, init);
    const text = await res.text();
    let data;
    try {
        data = JSON.parse(text);
    }
    catch {
        data = text;
    }
    if (!res.ok) {
        const msg = typeof data === 'string' ? data : data?.error || data?.message || JSON.stringify(data);
        throw new Error(`Server error ${res.status}: ${String(msg).slice(0, 200)}`);
    }
    return data;
}
