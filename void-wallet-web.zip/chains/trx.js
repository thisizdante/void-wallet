// Tron (BIP44 m/44'/195'/0'/0/i). Uses the TronGrid HTTP API; signing is done locally.
import { sha256 } from '@noble/hashes/sha256';
import { keccak_256 } from '@noble/hashes/sha3';
import { concatBytes, bytesToHex, hexToBytes } from '@noble/hashes/utils';
import { createBase58check } from '@scure/base';
import { secp256k1 } from '@noble/curves/secp256k1';
import { secpKey } from './keys.js';
import { getJson } from './types.js';
const b58c = createBase58check(sha256);
const keyAt = (seed, i) => {
    const { priv } = secpKey(seed, `m/44'/195'/0'/0/${i}`);
    const pub65 = secp256k1.getPublicKey(priv, false);
    const hash = keccak_256(pub65.slice(1)).slice(12);
    const addr = b58c.encode(concatBytes(Uint8Array.of(0x41), hash));
    return { priv, addr };
};
export function address(seed, _net, i) {
    return keyAt(seed, i).addr;
}
export function validate(addr) {
    try {
        const raw = b58c.decode(addr.trim());
        return raw.length === 21 && raw[0] === 0x41;
    }
    catch {
        return false;
    }
}
const post = (node, path, body) => getJson(`${node}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify(body),
});
async function account(node, addr) {
    const r = await post(node, '/wallet/getaccount', { address: addr, visible: true });
    if (!r || Object.keys(r).length === 0)
        return { exists: false, balance: 0n };
    return { exists: true, balance: BigInt(r.balance ?? 0) };
}
export async function balances(node, addrs) {
    return Promise.all(addrs.map(async (a) => (await account(node, a)).balance));
}
export async function used(node, addr) {
    return (await account(node, addr)).exists;
}
// Protobuf varint as hex (used to check the node's transaction against what we asked for).
function varintHex(n) {
    const out = [];
    let v = n;
    while (v >= 0x80n) {
        out.push(Number((v & 0x7fn) | 0x80n));
        v >>= 7n;
    }
    out.push(Number(v));
    return bytesToHex(Uint8Array.from(out));
}
export async function prepare(p) {
    if (p.amount === 'max')
        throw new Error('Max is not available for Tron. Enter an amount.');
    if (!validate(p.to))
        throw new Error('That is not a valid Tron address.');
    const amount = p.amount;
    const from = [...p.accounts].sort((a, b) => (a.balance > b.balance ? -1 : 1))[0];
    if (!from || from.balance <= 0n)
        throw new Error('No balance to send.');
    if (amount > from.balance) {
        const total = p.accounts.reduce((s, a) => s + a.balance, 0n);
        throw new Error(amount <= total
            ? 'Your TRX is spread across several addresses. One transaction can only spend from one address.'
            : 'Not enough TRX.');
    }
    const { priv } = keyAt(p.seed, from.index);
    const dest = await account(p.node, p.to.trim());
    const notes = [
        'Tron uses bandwidth for fees. If you have none, a small amount of TRX is burned (usually under 1 TRX).',
    ];
    let activation = 0n;
    if (!dest.exists) {
        activation = 1000000n;
        notes.push('The recipient address is not activated yet. Sending to it burns an extra 1 TRX to activate it.');
    }
    if (amount + activation > from.balance)
        throw new Error('Not enough TRX for this amount plus the activation fee.');
    // Ask the node to build the transaction, then verify it is what we asked for before signing.
    const tx = await post(p.node, '/wallet/createtransaction', {
        owner_address: from.address,
        to_address: p.to.trim(),
        amount: Number(amount),
        visible: true,
    });
    if (!tx || tx.Error || !tx.txID || !tx.raw_data_hex) {
        throw new Error(`Tron node could not build the transaction: ${tx?.Error ?? 'unknown error'}`);
    }
    const contract = tx.raw_data?.contract?.[0];
    const v = contract?.parameter?.value;
    if (contract?.type !== 'TransferContract' ||
        v?.owner_address !== from.address ||
        v?.to_address !== p.to.trim() ||
        BigInt(v?.amount ?? -1) !== amount) {
        throw new Error('The Tron node returned a different transaction than requested. Cancelled for safety.');
    }
    const raw = tx.raw_data_hex.toLowerCase();
    const ownerHex = bytesToHex(b58c.decode(from.address));
    const toHex = bytesToHex(b58c.decode(p.to.trim()));
    if (!raw.includes(`0a15${ownerHex}1215${toHex}18${varintHex(amount)}`)) {
        throw new Error('The transaction data does not match the request. Cancelled for safety.');
    }
    const txHash = sha256(hexToBytes(raw));
    if (bytesToHex(txHash) !== String(tx.txID).toLowerCase()) {
        throw new Error('Transaction hash mismatch. Cancelled for safety.');
    }
    return {
        amount,
        feeText: activation > 0n ? '1 TRX activation + bandwidth' : 'bandwidth (or under 1 TRX burned)',
        notes,
        fromAddress: from.address,
        execute: async () => {
            const sig = secp256k1.sign(txHash, priv, { lowS: true });
            const sigHex = bytesToHex(sig.toCompactRawBytes()) + (sig.recovery ?? 0).toString(16).padStart(2, '0');
            const res = await post(p.node, '/wallet/broadcasttransaction', { ...tx, signature: [sigHex] });
            if (!res?.result) {
                let msg = res?.message;
                try {
                    if (msg)
                        msg = new TextDecoder().decode(hexToBytes(msg));
                }
                catch {
                    // keep the raw message
                }
                throw new Error(`Broadcast failed: ${res?.code ?? ''} ${msg ?? ''}`.trim());
            }
            return { txid: res.txid ?? tx.txID };
        },
    };
}
