import { HDKey } from '@scure/bip32';
import { hmac } from '@noble/hashes/hmac';
import { sha512 } from '@noble/hashes/sha512';
import { utf8ToBytes } from '@noble/hashes/utils';
import { generateMnemonic, mnemonicToSeedSync, validateMnemonic } from '@scure/bip39';
import { wordlist } from '@scure/bip39/wordlists/english';
export function newMnemonic(words = 12) {
    return generateMnemonic(wordlist, words === 12 ? 128 : 256);
}
export function normalizeMnemonic(text) {
    return text.trim().toLowerCase().split(/\s+/).join(' ');
}
export function isValidMnemonic(text) {
    return validateMnemonic(normalizeMnemonic(text), wordlist);
}
export function seedFromMnemonic(mnemonic) {
    return mnemonicToSeedSync(normalizeMnemonic(mnemonic));
}
// secp256k1 key (BIP32) for Bitcoin, Ethereum, Tron and XRP.
export function secpKey(seed, path) {
    const node = HDKey.fromMasterSeed(seed).derive(path);
    if (!node.privateKey || !node.publicKey)
        throw new Error('Key derivation failed');
    return { priv: node.privateKey, pub: node.publicKey }; // pub is compressed (33 bytes)
}
// SLIP-0010 ed25519 derivation (all steps hardened) for Solana.
export function ed25519Seed(seed, indices) {
    let I = hmac(sha512, utf8ToBytes('ed25519 seed'), seed);
    let key = I.slice(0, 32);
    let chain = I.slice(32);
    for (const idx of indices) {
        const data = new Uint8Array(37);
        data[0] = 0;
        data.set(key, 1);
        new DataView(data.buffer).setUint32(33, (idx | 0x80000000) >>> 0, false);
        I = hmac(sha512, chain, data);
        key = I.slice(0, 32);
        chain = I.slice(32);
    }
    return key;
}
