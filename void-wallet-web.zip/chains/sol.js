// Solana (SLIP-0010 ed25519, path m/44'/501'/i'/0'). Uses @solana/web3.js v1.
import * as __ns1 from '@solana/web3.js';
const { Connection, Keypair, PublicKey, SystemProgram, Transaction } = {...__ns1, ...((typeof __ns1.default === 'object' || typeof __ns1.default === 'function') && __ns1.default ? __ns1.default : {})};
import { ed25519Seed } from './keys.js';
const keypairAt = (seed, i) => Keypair.fromSeed(ed25519Seed(seed, [44, 501, i, 0]));
export function address(seed, _net, i) {
    return keypairAt(seed, i).publicKey.toBase58();
}
export function validate(addr) {
    try {
        const pk = new PublicKey(addr.trim());
        return pk.toBytes().length === 32;
    }
    catch {
        return false;
    }
}
export async function balances(node, addrs) {
    const c = new Connection(node, 'confirmed');
    return Promise.all(addrs.map(async (a) => BigInt(await c.getBalance(new PublicKey(a)))));
}
export async function used(node, addr) {
    const c = new Connection(node, 'confirmed');
    const pk = new PublicKey(addr);
    const [bal, sigs] = await Promise.all([c.getBalance(pk), c.getSignaturesForAddress(pk, { limit: 1 })]);
    return bal > 0 || sigs.length > 0;
}
const FEE = 5000n; // lamports for a single-signature transfer
export async function prepare(p) {
    if (!validate(p.to))
        throw new Error('That is not a valid Solana address.');
    const conn = new Connection(p.node, 'confirmed');
    const toPk = new PublicKey(p.to.trim());
    const from = [...p.accounts].sort((a, b) => (a.balance > b.balance ? -1 : 1))[0];
    if (!from || from.balance <= 0n)
        throw new Error('No balance to send.');
    const kp = keypairAt(p.seed, from.index);
    const minRent = BigInt(await conn.getMinimumBalanceForRentExemption(0));
    const recipientBal = BigInt(await conn.getBalance(toPk));
    let amount;
    if (p.amount === 'max') {
        amount = from.balance - FEE;
        if (amount <= 0n)
            throw new Error('Balance is too small to cover the network fee.');
    }
    else {
        amount = p.amount;
        if (amount + FEE > from.balance) {
            const total = p.accounts.reduce((s, a) => s + a.balance, 0n);
            throw new Error(amount + FEE <= total
                ? 'Your SOL is spread across several addresses. One transaction can only spend from one address.'
                : 'Not enough SOL for this amount plus the network fee.');
        }
        const remaining = from.balance - amount - FEE;
        if (remaining > 0n && remaining < minRent) {
            throw new Error('This would leave less than the ~0.00089 SOL Solana requires an account to keep. Send a bit less, or use Max to send everything.');
        }
    }
    if (recipientBal === 0n && amount < minRent) {
        throw new Error('A new Solana address needs at least ~0.00089 SOL on its first receive. Send a larger amount.');
    }
    return {
        amount,
        feeText: '0.000005 SOL',
        notes: [],
        fromAddress: from.address,
        execute: async () => {
            const { blockhash } = await conn.getLatestBlockhash('confirmed');
            const tx = new Transaction();
            tx.recentBlockhash = blockhash;
            tx.feePayer = kp.publicKey;
            tx.add(SystemProgram.transfer({ fromPubkey: kp.publicKey, toPubkey: toPk, lamports: Number(amount) }));
            tx.sign(kp);
            const txid = await conn.sendRawTransaction(tx.serialize());
            return { txid };
        },
    };
}
