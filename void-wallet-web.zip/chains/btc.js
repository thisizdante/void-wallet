// Bitcoin: native SegWit (P2WPKH, "bc1q..." / "tb1q...") addresses, BIP84 derivation.
// Transactions are built and signed here (BIP143) and sent through a mempool.space-compatible API.
import { sha256 } from '@noble/hashes/sha256';
import { ripemd160 } from '@noble/hashes/ripemd160';
import { concatBytes, bytesToHex, hexToBytes } from '@noble/hashes/utils';
import { bech32, bech32m, createBase58check } from '@scure/base';
import { secp256k1 } from '@noble/curves/secp256k1';
import { secpKey } from './keys.js';
import { getJson } from './types.js';
const b58c = createBase58check(sha256);
const sha256d = (b) => sha256(sha256(b));
const hash160 = (b) => ripemd160(sha256(b));
const SEQUENCE = 0xfffffffd; // opt in to replace-by-fee
const DUST = 546n;
const hrp = (net) => (net === 'main' ? 'bc' : 'tb');
const pathFor = (net, i) => `m/84'/${net === 'main' ? 0 : 1}'/0'/0/${i}`;
export function address(seed, net, i) {
    const { pub } = secpKey(seed, pathFor(net, i));
    const words = bech32.toWords(hash160(pub));
    return bech32.encode(hrp(net), [0, ...words]);
}
// ---------- encoding helpers ----------
const u32le = (n) => {
    const b = new Uint8Array(4);
    new DataView(b.buffer).setUint32(0, n >>> 0, true);
    return b;
};
const u64le = (n) => {
    const b = new Uint8Array(8);
    new DataView(b.buffer).setBigUint64(0, n, true);
    return b;
};
const varint = (n) => {
    if (n < 0xfd)
        return Uint8Array.of(n);
    if (n <= 0xffff)
        return Uint8Array.of(0xfd, n & 0xff, (n >> 8) & 0xff);
    throw new Error('varint too large');
};
// ---------- destination address -> output script ----------
function scriptFor(addr, net) {
    const a = addr.trim();
    const lower = a.toLowerCase();
    if (lower.startsWith(hrp(net) + '1')) {
        if (a !== lower && a !== a.toUpperCase())
            throw new Error('Mixed-case address');
        let decoded;
        let isM = false;
        try {
            decoded = bech32.decode(lower, 200);
        }
        catch {
            decoded = bech32m.decode(lower, 200);
            isM = true;
        }
        if (decoded.prefix !== hrp(net))
            throw new Error('Wrong network');
        const ver = decoded.words[0];
        const prog = Uint8Array.from(bech32.fromWords(decoded.words.slice(1)));
        if (ver === 0) {
            if (isM)
                throw new Error('Bad address checksum type');
            if (prog.length !== 20 && prog.length !== 32)
                throw new Error('Bad address length');
            return concatBytes(Uint8Array.of(0x00, prog.length), prog);
        }
        if (ver === 1) {
            if (!isM)
                throw new Error('Bad address checksum type');
            if (prog.length !== 32)
                throw new Error('Bad address length');
            return concatBytes(Uint8Array.of(0x51, 0x20), prog);
        }
        throw new Error('Unsupported address version');
    }
    const raw = b58c.decode(a);
    if (raw.length !== 21)
        throw new Error('Bad address length');
    const h = raw.slice(1);
    const p2pkh = net === 'main' ? 0x00 : 0x6f;
    const p2sh = net === 'main' ? 0x05 : 0xc4;
    if (raw[0] === p2pkh)
        return concatBytes(Uint8Array.of(0x76, 0xa9, 0x14), h, Uint8Array.of(0x88, 0xac));
    if (raw[0] === p2sh)
        return concatBytes(Uint8Array.of(0xa9, 0x14), h, Uint8Array.of(0x87));
    throw new Error('Wrong network');
}
;
export function validate(addr, net) {
    try {
        scriptFor(addr, net);
        return true;
    }
    catch {
        return false;
    }
}
async function stats(node, addr) {
    return getJson(`${node}/address/${addr}`);
}
export async function balances(node, addrs) {
    return Promise.all(addrs.map(async (a) => {
        const s = await stats(node, a);
        const v = s.chain_stats.funded_txo_sum -
            s.chain_stats.spent_txo_sum +
            s.mempool_stats.funded_txo_sum -
            s.mempool_stats.spent_txo_sum;
        return BigInt(v);
    }));
}
export async function used(node, addr) {
    const s = await stats(node, addr);
    return s.chain_stats.tx_count + s.mempool_stats.tx_count > 0;
}
async function feeRate(node, level) {
    try {
        const f = await getJson(`${node}/v1/fees/recommended`);
        const r = level === 'slow' ? f.hourFee : level === 'fast' ? f.fastestFee : f.halfHourFee;
        if (typeof r === 'number' && r > 0)
            return r;
    }
    catch {
        // fall through to the Esplora-style estimate
    }
    const est = await getJson(`${node}/fee-estimates`);
    const target = level === 'slow' ? '6' : level === 'fast' ? '1' : '3';
    const r = est[target];
    if (typeof r === 'number' && r > 0)
        return Math.max(1, Math.ceil(r));
    throw new Error('Could not get a fee rate from the Bitcoin server');
}
// ---------- sending ----------
export async function prepare(p) {
    if (!validate(p.to, p.net))
        throw new Error('That is not a valid Bitcoin address for this network.');
    const outScript = scriptFor(p.to, p.net);
    // Collect confirmed coins from every address we own.
    const utxos = [];
    for (const acc of p.accounts) {
        if (acc.balance <= 0n)
            continue;
        const list = await getJson(`${p.node}/address/${acc.address}/utxo`);
        for (const u of list) {
            if (u.status?.confirmed) {
                utxos.push({ txid: u.txid, vout: u.vout, value: BigInt(u.value), index: acc.index, address: acc.address });
            }
        }
    }
    if (utxos.length === 0)
        throw new Error('No confirmed bitcoin to spend yet. Wait for confirmations.');
    utxos.sort((a, b) => (a.value > b.value ? -1 : a.value < b.value ? 1 : 0));
    const rate = await feeRate(p.node, p.level);
    const vbytes = (nIn, nOut) => Math.ceil(11 + 68 * nIn + 31 * (nOut - 1) + 43);
    const feeFor = (nIn, nOut) => BigInt(Math.ceil(vbytes(nIn, nOut) * rate));
    let chosen = [];
    let total = 0n;
    let amount;
    let fee;
    let change = 0n;
    if (p.amount === 'max') {
        chosen = utxos;
        total = chosen.reduce((s, u) => s + u.value, 0n);
        fee = feeFor(chosen.length, 1);
        amount = total - fee;
        if (amount < DUST)
            throw new Error('Balance is too small to cover the network fee.');
    }
    else {
        amount = p.amount;
        if (amount < DUST)
            throw new Error('Amount is below the minimum (dust) of 546 sats.');
        for (const u of utxos) {
            chosen.push(u);
            total += u.value;
            if (total >= amount + feeFor(chosen.length, 2))
                break;
        }
        const feeTwo = feeFor(chosen.length, 2);
        if (total < amount + feeFor(chosen.length, 1)) {
            throw new Error('Not enough confirmed balance for this amount plus the network fee.');
        }
        if (total - amount - feeTwo >= DUST) {
            fee = feeTwo;
            change = total - amount - feeTwo;
        }
        else {
            fee = total - amount; // change would be dust, give it to the miners
        }
    }
    const changeIndex = p.nextIndex;
    const outs = [{ value: amount, script: outScript }];
    if (change > 0n) {
        const changeAddr = address(p.seed, p.net, changeIndex);
        outs.push({ value: change, script: scriptFor(changeAddr, p.net) });
    }
    // ---- BIP143 signing ----
    const ins = chosen.map((u) => ({
        ...u,
        txidLE: Uint8Array.from(hexToBytes(u.txid)).reverse(),
        key: secpKey(p.seed, pathFor(p.net, u.index)),
    }));
    const hashPrevouts = sha256d(concatBytes(...ins.map((i) => concatBytes(i.txidLE, u32le(i.vout)))));
    const hashSequence = sha256d(concatBytes(...ins.map(() => u32le(SEQUENCE))));
    const outsSer = outs.map((o) => concatBytes(u64le(o.value), varint(o.script.length), o.script));
    const hashOutputs = sha256d(concatBytes(...outsSer));
    const witnesses = ins.map((i) => {
        const scriptCode = concatBytes(Uint8Array.of(0x19, 0x76, 0xa9, 0x14), hash160(i.key.pub), Uint8Array.of(0x88, 0xac));
        const preimage = concatBytes(u32le(2), hashPrevouts, hashSequence, i.txidLE, u32le(i.vout), scriptCode, u64le(i.value), u32le(SEQUENCE), hashOutputs, u32le(0), u32le(1) // SIGHASH_ALL
        );
        const sig = secp256k1.sign(sha256d(preimage), i.key.priv, { lowS: true });
        const der = concatBytes(sig.toDERRawBytes(), Uint8Array.of(0x01));
        return concatBytes(Uint8Array.of(0x02), varint(der.length), der, varint(i.key.pub.length), i.key.pub);
    });
    const raw = concatBytes(u32le(2), Uint8Array.of(0x00, 0x01), varint(ins.length), ...ins.map((i) => concatBytes(i.txidLE, u32le(i.vout), Uint8Array.of(0x00), u32le(SEQUENCE))), varint(outs.length), ...outsSer, ...witnesses, u32le(0));
    const rawHex = bytesToHex(raw);
    const notes = [];
    notes.push(`Fee rate ${rate} sat/vB (${p.level}).`);
    if (change === 0n && p.amount !== 'max')
        notes.push('Change was too small to keep, so it is added to the fee.');
    if (chosen.length > 1)
        notes.push(`Spending from ${chosen.length} inputs.`);
    return {
        amount,
        feeText: `${(Number(fee) / 1e8).toFixed(8)} BTC`,
        notes,
        fromAddress: chosen[0].address,
        execute: async () => {
            const res = await fetch(`${p.node}/tx`, { method: 'POST', body: rawHex });
            const text = await res.text();
            if (!res.ok)
                throw new Error(`Broadcast failed: ${text.slice(0, 200)}`);
            return { txid: text.trim(), usedIndex: change > 0n ? changeIndex : undefined };
        },
    };
}
