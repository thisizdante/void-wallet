// XRP Ledger (BIP44 m/44'/144'/0'/0/i, secp256k1). JSON-RPC to a rippled server; signing is local.
import { sha256 } from '@noble/hashes/sha256';
import { sha512 } from '@noble/hashes/sha512';
import { ripemd160 } from '@noble/hashes/ripemd160';
import { concatBytes, bytesToHex, hexToBytes } from '@noble/hashes/utils';
import { base58xrp } from '@scure/base';
import { secp256k1 } from '@noble/curves/secp256k1';
import * as __ns4 from 'ripple-binary-codec';
const { encode, encodeForSigning } = {...__ns4, ...((typeof __ns4.default === 'object' || typeof __ns4.default === 'function') && __ns4.default ? __ns4.default : {})};
import * as __ns5 from 'ripple-address-codec';
const { isValidClassicAddress } = {...__ns5, ...((typeof __ns5.default === 'object' || typeof __ns5.default === 'function') && __ns5.default ? __ns5.default : {})};
import { secpKey } from './keys.js';
import { getJson } from './types.js';
const keyAt = (seed, i) => {
    const { priv, pub } = secpKey(seed, `m/44'/144'/0'/0/${i}`);
    const id = ripemd160(sha256(pub));
    const payload = concatBytes(Uint8Array.of(0x00), id);
    const checksum = sha256(sha256(payload)).slice(0, 4);
    return { priv, pub, addr: base58xrp.encode(concatBytes(payload, checksum)) };
};
export function address(seed, _net, i) {
    return keyAt(seed, i).addr;
}
export function validate(addr) {
    const a = addr.trim();
    return a.startsWith('r') && isValidClassicAddress(a);
}
async function rpc(node, method, params = {}) {
    const data = await getJson(node, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ method, params: [params] }),
    });
    return data.result;
}
async function info(node, addr) {
    const r = await rpc(node, 'account_info', { account: addr, ledger_index: 'validated' });
    if (r?.error === 'actNotFound')
        return { exists: false, balance: 0n, sequence: 0, ownerCount: 0 };
    if (r?.status !== 'success' || !r.account_data) {
        throw new Error(`XRP server error: ${r?.error_message ?? r?.error ?? 'unknown'}`);
    }
    return {
        exists: true,
        balance: BigInt(r.account_data.Balance),
        sequence: r.account_data.Sequence,
        ownerCount: r.account_data.OwnerCount ?? 0,
    };
}
export async function balances(node, addrs) {
    return Promise.all(addrs.map(async (a) => (await info(node, a)).balance));
}
export async function used(node, addr) {
    return (await info(node, addr)).exists;
}
async function reserves(node) {
    const r = await rpc(node, 'server_info');
    const v = r?.info?.validated_ledger;
    if (v?.reserve_base_xrp == null || v?.reserve_inc_xrp == null)
        throw new Error('Could not read the XRP reserve.');
    return {
        base: BigInt(Math.round(Number(v.reserve_base_xrp) * 1e6)),
        inc: BigInt(Math.round(Number(v.reserve_inc_xrp) * 1e6)),
    };
}
export async function prepare(p) {
    if (p.amount === 'max')
        throw new Error('Max is not available for XRP. Enter an amount.');
    const to = p.to.trim();
    if (!validate(to))
        throw new Error('That is not a valid XRP address (classic "r..." format).');
    const amount = p.amount;
    let tag;
    if (p.tag && p.tag.trim() !== '') {
        if (!/^\d+$/.test(p.tag.trim()) || Number(p.tag) > 4294967295)
            throw new Error('Destination tag must be a number.');
        tag = Number(p.tag.trim());
    }
    const from = [...p.accounts].sort((a, b) => (a.balance > b.balance ? -1 : 1))[0];
    if (!from || from.balance <= 0n)
        throw new Error('No balance to send.');
    const key = keyAt(p.seed, from.index);
    const [acct, dest, res, feeRes] = await Promise.all([
        info(p.node, from.address),
        info(p.node, to),
        reserves(p.node),
        rpc(p.node, 'fee'),
    ]);
    const openFee = BigInt(feeRes?.drops?.open_ledger_fee ?? feeRes?.drops?.base_fee ?? '12');
    const fee = (openFee * 12n) / 10n + 1n; // small margin so it does not get stuck
    const ledger = Number(feeRes?.ledger_current_index);
    if (!ledger)
        throw new Error('Could not read the current ledger.');
    const reserve = res.base + BigInt(acct.ownerCount) * res.inc;
    if (acct.balance - amount - fee < reserve) {
        throw new Error(`XRP accounts must keep a reserve of ${Number(reserve) / 1e6} XRP. You can send up to ${Number(acct.balance - fee - reserve > 0n ? acct.balance - fee - reserve : 0n) / 1e6} XRP from this address.`);
    }
    if (!dest.exists && amount < res.base) {
        throw new Error(`The recipient is not activated. The first payment must be at least ${Number(res.base) / 1e6} XRP.`);
    }
    const notes = [];
    if (tag === undefined)
        notes.push('No destination tag. Exchanges usually require one, so check before sending.');
    const tx = {
        TransactionType: 'Payment',
        Account: from.address,
        Destination: to,
        Amount: amount.toString(),
        Fee: fee.toString(),
        Sequence: acct.sequence,
        LastLedgerSequence: ledger + 20,
        Flags: 2147483648, // tfFullyCanonicalSig
        SigningPubKey: bytesToHex(key.pub).toUpperCase(),
    };
    if (tag !== undefined)
        tx.DestinationTag = tag;
    return {
        amount,
        feeText: `${Number(fee) / 1e6} XRP`,
        notes,
        fromAddress: from.address,
        execute: async () => {
            const toSign = hexToBytes(encodeForSigning(tx));
            const hash = sha512(toSign).slice(0, 32);
            const sig = secp256k1.sign(hash, key.priv, { lowS: true }).toDERHex().toUpperCase();
            const blob = encode({ ...tx, TxnSignature: sig });
            const r = await rpc(p.node, 'submit', { tx_blob: blob });
            const code = r?.engine_result ?? r?.error ?? 'unknown';
            if (!(code.startsWith('tes') || code === 'terQUEUED')) {
                throw new Error(`XRP submit failed: ${code} ${r?.engine_result_message ?? r?.error_message ?? ''}`.trim());
            }
            return { txid: r.tx_json?.hash ?? '' };
        },
    };
}
