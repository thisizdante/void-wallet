// Stellar (SEP-0005 path m/44'/148'/i', ed25519). Uses @stellar/stellar-base for addresses and transaction
// building/signing, and a Horizon server over HTTPS for balances and submitting.
import * as __ns3 from '@stellar/stellar-base';
const { Account, Asset, Keypair, Memo, Networks, Operation, StrKey, TransactionBuilder } = {...__ns3, ...((typeof __ns3.default === 'object' || typeof __ns3.default === 'function') && __ns3.default ? __ns3.default : {})};
import { ed25519Seed } from './keys.js';
import { formatUnits } from './config.js';
import { getJson } from './types.js';
const keypairAt = (seed, i) => Keypair.fromRawEd25519Seed(Buffer.from(ed25519Seed(seed, [44, 148, i])));
export function address(seed, _net, i) {
    return keypairAt(seed, i).publicKey();
}
export function validate(addr) {
    return StrKey.isValidEd25519PublicKey(addr.trim());
}
const STROOPS = 10000000n;
const toStroops = (s) => {
    const [w, f = ''] = String(s).split('.');
    return BigInt(w || '0') * STROOPS + BigInt(f.padEnd(7, '0').slice(0, 7) || '0');
};
async function account(node, addr) {
    const res = await fetch(`${node}/accounts/${addr}`);
    if (res.status === 404) {
        return { exists: false, balance: 0n, selling: 0n, sequence: '0', subentries: 0, sponsoring: 0, sponsored: 0 };
    }
    if (!res.ok)
        throw new Error(`Stellar server error ${res.status}`);
    const j = await res.json();
    const native = (j.balances ?? []).find((b) => b.asset_type === 'native');
    return {
        exists: true,
        balance: native ? toStroops(native.balance) : 0n,
        selling: native?.selling_liabilities ? toStroops(native.selling_liabilities) : 0n,
        sequence: String(j.sequence),
        subentries: Number(j.subentry_count ?? 0),
        sponsoring: Number(j.num_sponsoring ?? 0),
        sponsored: Number(j.num_sponsored ?? 0),
    };
}
export async function balances(node, addrs) {
    return Promise.all(addrs.map(async (a) => (await account(node, a)).balance));
}
export async function used(node, addr) {
    return (await account(node, addr)).exists;
}
async function networkInfo(node) {
    const ledgers = await getJson(`${node}/ledgers?order=desc&limit=1`);
    const rec = ledgers?._embedded?.records?.[0];
    if (rec?.base_reserve_in_stroops == null)
        throw new Error('Could not read the Stellar reserve.');
    let fee = 100;
    try {
        const stats = await getJson(`${node}/fee_stats`);
        fee = Math.max(100, Number(stats?.fee_charged?.p70 ?? 100) || 100);
    }
    catch {
        // fall back to the base fee
    }
    return { reserve: BigInt(rec.base_reserve_in_stroops), fee: BigInt(fee) };
}
export async function prepare(p) {
    if (p.amount === 'max')
        throw new Error('Max is not available for Stellar. Enter an amount.');
    const to = p.to.trim();
    if (!validate(to))
        throw new Error('That is not a valid Stellar address (it should start with G).');
    const amount = p.amount;
    const from = [...p.accounts].sort((a, b) => (a.balance > b.balance ? -1 : 1))[0];
    if (!from || from.balance <= 0n)
        throw new Error('No balance to send.');
    const key = keypairAt(p.seed, from.index);
    const memoText = (p.tag ?? '').trim();
    let memo;
    if (memoText) {
        if (/^\d+$/.test(memoText))
            memo = Memo.id(memoText);
        else if (Buffer.byteLength(memoText, 'utf8') <= 28)
            memo = Memo.text(memoText);
        else
            throw new Error('A text memo can be at most 28 characters.');
    }
    const [acct, dest, net] = await Promise.all([account(p.node, from.address), account(p.node, to), networkInfo(p.node)]);
    if (!acct.exists)
        throw new Error('This Stellar address is not activated yet, so it cannot send.');
    const minBalance = (2n + BigInt(acct.subentries) + BigInt(acct.sponsoring) - BigInt(acct.sponsored)) * net.reserve;
    const spendable = acct.balance - acct.selling - minBalance - net.fee;
    if (amount > spendable) {
        const total = p.accounts.reduce((s, a) => s + a.balance, 0n);
        if (amount <= total && p.accounts.length > 1) {
            throw new Error('Your XLM is spread across several addresses. One transaction can only spend from one address.');
        }
        throw new Error(`Stellar accounts must keep a reserve of ${formatUnits(minBalance, 7, 7)} XLM. You can send up to ${formatUnits(spendable > 0n ? spendable : 0n, 7, 7)} XLM from this address.`);
    }
    const notes = [];
    let op;
    if (dest.exists) {
        op = Operation.payment({ destination: to, asset: Asset.native(), amount: formatUnits(amount, 7, 7) });
    }
    else {
        if (amount < 2n * net.reserve) {
            throw new Error(`The recipient is not activated. The first payment must be at least ${formatUnits(2n * net.reserve, 7, 7)} XLM.`);
        }
        op = Operation.createAccount({ destination: to, startingBalance: formatUnits(amount, 7, 7) });
        notes.push('The recipient address is new, so this payment also activates it.');
    }
    if (!memo)
        notes.push('No memo. Exchanges usually require one, so check before sending.');
    const builder = new TransactionBuilder(new Account(from.address, acct.sequence), {
        fee: net.fee.toString(),
        networkPassphrase: p.net === 'main' ? Networks.PUBLIC : Networks.TESTNET,
    }).addOperation(op);
    if (memo)
        builder.addMemo(memo);
    const tx = builder.setTimeout(180).build();
    tx.sign(key);
    const xdr = tx.toXDR();
    const hash = Buffer.from(tx.hash()).toString('hex');
    return {
        amount,
        feeText: `${formatUnits(net.fee, 7, 7)} XLM`,
        notes,
        fromAddress: from.address,
        execute: async () => {
            const res = await getJson(`${p.node}/transactions`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `tx=${encodeURIComponent(xdr)}`,
            });
            return { txid: res?.hash ?? hash };
        },
    };
}
