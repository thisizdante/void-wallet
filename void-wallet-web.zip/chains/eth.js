// Ethereum (BIP44 m/44'/60'/0'/0/i). Uses ethers v6 for addresses, fees and signing.
import * as __ns2 from 'ethers';
const { Wallet, JsonRpcProvider, isAddress, formatEther } = {...__ns2, ...((typeof __ns2.default === 'object' || typeof __ns2.default === 'function') && __ns2.default ? __ns2.default : {})};
import { bytesToHex } from '@noble/hashes/utils';
import { secpKey } from './keys.js';
const keyAt = (seed, i) => secpKey(seed, `m/44'/60'/0'/0/${i}`);
const provider = (node) => new JsonRpcProvider(node);
export function address(seed, _net, i) {
    return new Wallet('0x' + bytesToHex(keyAt(seed, i).priv)).address;
}
export function validate(addr) {
    return isAddress(addr.trim());
}
export async function balances(node, addrs) {
    const p = provider(node);
    return Promise.all(addrs.map((a) => p.getBalance(a)));
}
export async function used(node, addr) {
    const p = provider(node);
    const [nonce, bal] = await Promise.all([p.getTransactionCount(addr), p.getBalance(addr)]);
    return nonce > 0 || bal > 0n;
}
export async function prepare(p) {
    if (!validate(p.to))
        throw new Error('That is not a valid Ethereum address.');
    const prov = provider(p.node);
    // Send from the address that holds the most.
    const from = [...p.accounts].sort((a, b) => (a.balance > b.balance ? -1 : 1))[0];
    if (!from || from.balance <= 0n)
        throw new Error('No balance to send.');
    const wallet = new Wallet('0x' + bytesToHex(keyAt(p.seed, from.index).priv), prov);
    const [block, feeData] = await Promise.all([prov.getBlock('latest'), prov.getFeeData()]);
    const baseFee = block?.baseFeePerGas ?? feeData.gasPrice;
    if (baseFee == null)
        throw new Error('Could not read the network fee.');
    const normalTip = feeData.maxPriorityFeePerGas ?? 1000000000n;
    const tip = p.level === 'slow' ? normalTip / 2n : p.level === 'fast' ? normalTip * 2n : normalTip;
    const maxFeePerGas = baseFee * 2n + tip;
    const probeValue = p.amount === 'max' ? 1n : p.amount;
    const gasLimit = await prov.estimateGas({ from: wallet.address, to: p.to.trim(), value: probeValue });
    const maxFee = gasLimit * maxFeePerGas;
    let amount;
    if (p.amount === 'max') {
        amount = from.balance - maxFee;
        if (amount <= 0n)
            throw new Error('Balance is too small to cover the network fee.');
    }
    else {
        amount = p.amount;
        if (amount + maxFee > from.balance) {
            const total = p.accounts.reduce((s, a) => s + a.balance, 0n);
            if (amount + maxFee <= total) {
                throw new Error('Your ETH is spread across several addresses. One transaction can only spend from one address, so this amount is too large.');
            }
            throw new Error('Not enough ETH for this amount plus the network fee.');
        }
    }
    const notes = [`Fee is an upper limit; you usually pay less. Speed: ${p.level}.`];
    if (p.accounts.length > 1)
        notes.push(`Sending from the address holding the most (${from.address.slice(0, 8)}…).`);
    return {
        amount,
        feeText: `up to ${Number(formatEther(maxFee)).toFixed(6)} ETH`,
        notes,
        fromAddress: from.address,
        execute: async () => {
            const resp = await wallet.sendTransaction({
                to: p.to.trim(),
                value: amount,
                gasLimit,
                maxFeePerGas,
                maxPriorityFeePerGas: tip,
                type: 2,
            });
            return { txid: resp.hash };
        },
    };
}
