// Coins that work in this build. Monero arrives in phase 3.
export const LIVE_COINS = ['BTC', 'ETH', 'TRX', 'SOL', 'XRP', 'XLM'];
export const COINS = {
    BTC: { name: 'Bitcoin', symbol: 'BTC', decimals: 8, coingecko: 'bitcoin', color: '#F7931A' },
    ETH: { name: 'Ethereum', symbol: 'ETH', decimals: 18, coingecko: 'ethereum', color: '#8C9EFF' },
    TRX: { name: 'Tron', symbol: 'TRX', decimals: 6, coingecko: 'tron', color: '#EF4444' },
    SOL: { name: 'Solana', symbol: 'SOL', decimals: 9, coingecko: 'solana', color: '#14F195' },
    XRP: { name: 'XRP', symbol: 'XRP', decimals: 6, coingecko: 'ripple', color: '#9CA3AF' },
    XLM: { name: 'Stellar', symbol: 'XLM', decimals: 7, coingecko: 'stellar', color: '#6EC1FF' },
    XMR: { name: 'Monero', symbol: 'XMR', decimals: 12, coingecko: 'monero', color: '#FF6600' },
};
// Default public servers. All of them can be replaced in Settings -> Nodes.
// These addresses were not tested from the build workspace (it had no network access).
export const DEFAULT_NODES = {
    main: {
        BTC: 'https://mempool.space/api',
        ETH: 'https://ethereum-rpc.publicnode.com',
        TRX: 'https://api.trongrid.io',
        SOL: 'https://api.mainnet-beta.solana.com',
        XRP: 'https://xrplcluster.com',
        XLM: 'https://horizon.stellar.org',
    },
    test: {
        BTC: 'https://mempool.space/testnet4/api',
        ETH: 'https://ethereum-sepolia-rpc.publicnode.com',
        TRX: 'https://api.shasta.trongrid.io',
        SOL: 'https://api.devnet.solana.com',
        XRP: 'https://s.altnet.rippletest.net:51234',
        XLM: 'https://horizon-testnet.stellar.org',
    },
};
const EXPLORERS = {
    main: {
        BTC: (id) => `https://mempool.space/tx/${id}`,
        ETH: (id) => `https://etherscan.io/tx/${id}`,
        TRX: (id) => `https://tronscan.org/#/transaction/${id}`,
        SOL: (id) => `https://solscan.io/tx/${id}`,
        XRP: (id) => `https://livenet.xrpl.org/transactions/${id}`,
        XLM: (id) => `https://stellar.expert/explorer/public/tx/${id}`,
    },
    test: {
        BTC: (id) => `https://mempool.space/testnet4/tx/${id}`,
        ETH: (id) => `https://sepolia.etherscan.io/tx/${id}`,
        TRX: (id) => `https://shasta.tronscan.org/#/transaction/${id}`,
        SOL: (id) => `https://solscan.io/tx/${id}?cluster=devnet`,
        XRP: (id) => `https://testnet.xrpl.org/transactions/${id}`,
        XLM: (id) => `https://stellar.expert/explorer/testnet/tx/${id}`,
    },
};
export function explorerUrl(coin, net, txid) {
    return EXPLORERS[net][coin](txid);
}
// ---- amount helpers (all money is handled as bigint in the smallest unit) ----
export function formatUnits(amount, decimals, maxFraction = 8) {
    const neg = amount < 0n;
    const abs = neg ? -amount : amount;
    const base = 10n ** BigInt(decimals);
    const whole = abs / base;
    let frac = (abs % base).toString().padStart(decimals, '0');
    frac = frac.slice(0, maxFraction).replace(/0+$/, '');
    return `${neg ? '-' : ''}${whole.toString()}${frac ? '.' + frac : ''}`;
}
// Returns null when the text is not a valid positive amount with at most `decimals` decimals.
export function parseUnits(text, decimals) {
    const t = text.trim().replace(',', '.');
    if (!/^\d*\.?\d*$/.test(t) || t === '' || t === '.')
        return null;
    const [whole, frac = ''] = t.split('.');
    if (frac.length > decimals)
        return null;
    const v = BigInt(whole || '0') * 10n ** BigInt(decimals) + BigInt(frac.padEnd(decimals, '0') || '0');
    return v > 0n ? v : null;
}
export function toUsd(amount, decimals, price) {
    // Convert via Number only after scaling down, which is fine for display purposes.
    return (Number(amount) / 10 ** decimals) * price;
}
export function fmtUsd(v) {
    return v.toLocaleString('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 2 });
}
