// Loads each coin's code (and its libraries from the CDN) only when it is needed, so one failing
// library disables that coin instead of the whole app.
const COIN_MOD = { BTC: 'btc', ETH: 'eth', TRX: 'trx', SOL: 'sol', XRP: 'xrp', XLM: 'xlm' };

async function ensureBuffer() {
  if (globalThis.Buffer) return;
  const m = await import('https://cdn.jsdelivr.net/npm/buffer@6.0.3/+esm');
  globalThis.Buffer = m.Buffer || (m.default && m.default.Buffer);
}

const cache = {};
function mod(name) {
  if (!cache[name]) {
    cache[name] = (async () => {
      await ensureBuffer();
      return import(`./chains/${name}.js`);
    })().catch((e) => {
      delete cache[name];
      throw new Error(`could not load ${name} (${e && e.message ? e.message : e})`);
    });
  }
  return cache[name];
}

export async function ready() {
  await mod('keys');
}
export async function newMnemonic(words = 12) {
  return (await mod('keys')).newMnemonic(words);
}
export async function isValidMnemonic(text) {
  return (await mod('keys')).isValidMnemonic(text);
}
export async function normalizeMnemonic(text) {
  return (await mod('keys')).normalizeMnemonic(text);
}
export async function seedFromMnemonic(text) {
  return (await mod('keys')).seedFromMnemonic(text);
}

export async function addressAt(coin, seed, net, i) {
  return (await mod(COIN_MOD[coin])).address(seed, net, i);
}
export async function validateAddress(coin, net, addr) {
  const m = await mod(COIN_MOD[coin]);
  return coin === 'BTC' ? m.validate(addr, net) : m.validate(addr);
}
export async function fetchBalances(coin, node, addrs) {
  return (await mod(COIN_MOD[coin])).balances(node, addrs);
}
export async function addressUsed(coin, node, addr) {
  return (await mod(COIN_MOD[coin])).used(node, addr);
}
export async function prepareSend(p) {
  return (await mod(COIN_MOD[p.coin])).prepare(p);
}

export const SUPPORTS_MAX = { BTC: true, ETH: true, SOL: true, TRX: false, XRP: false, XLM: false };
export const SUPPORTS_FEE_LEVEL = { BTC: true, ETH: true, SOL: false, TRX: false, XRP: false, XLM: false };
